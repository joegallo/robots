#!/bin/sh
pwd=`pwd`
cd ${0%/*}
java -Xmx512M -Dsun.io.useCanonCaches=false -DNOSECURITY=true -cp clojure-1.2.0.jar:clojure-contrib-1.2.0.jar:./libs/*: robocode.Robocode $*
cd $pwd
