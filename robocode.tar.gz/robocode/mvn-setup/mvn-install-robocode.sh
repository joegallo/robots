mvn install:install-file \
    -Dfile=robocode-1.7.0.2.jar \
    -DgroupId=robocode \
    -DartifactId=robocode \
    -Dversion=1.7.0.2 \
    -Dpackaging=jar \
    -DgeneratePom=true
